# Elasticsearch Search Tutorial

This directory contains a starter Flask project used in the Search tutorial.
