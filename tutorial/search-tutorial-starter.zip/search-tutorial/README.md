# Elasticsearch Tutorial

This directory contains a starter Flask project used in the Search Labs Elasticsearch tutorial.
